import argparse
from printBoard import printBoard
from localSearch import localSearch
from hill_climbing import hill_climbing
from hill_climbing import random_restart
from NQueens import NQueensSearch

if __name__ == "__main__":

    
    str = "N-queens problem solver by using local search algorithms."
    parser = argparse.ArgumentParser(description=str)
    parser.add_argument("-n", type=int, default=8, help="Size of the board")
    parser.add_argument("-i", type=int, default=10, help="Number of iterations")
    parser.add_argument("--all", type=int, dest='all', action='store',
                        choices=range(0, 2), default=0,
                        help="0 = show one solution | 1 = show all solutions")
    args = parser.parse_args()
    test = localSearch()
    problem = NQueensSearch(args.n)
    algorithms = [hill_climbing]
    names = ["hill_climbing"]
    problems = [problem, problem, problem]
    for i in range(len(algorithms)):
        print names[i]
        result_board = test.localSearch(problems[i], algorithms[i], args.i)

       
        printBoard(result_board, args.all)
